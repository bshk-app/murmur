Bergamot source accompanying Murmator for iOS

Upstream: https://github.com/browsermt/bergamot-translator
Revision: 9271618ebbdc5d21ac4dc4df9e72beb7ce644774
License: MPL-2.0 (bergamot/LICENSE)

The bergamot directory contains the tracked source form from the source tree used for the native iOS build. Git submodules are separate dependencies. Obtain them using the recorded revisions and the .gitmodules files. The integration directory contains the Murmator C interfaces, iOS build script and architecture patch; it is covered by integration/LICENSE.

Set BERG_SOURCE and CT2_SOURCE in the included build script to local checkouts. CTranslate2: https://github.com/OpenNMT/CTranslate2 at d44d2d069eb88c7b7804da864c10c201501cb4a9. PCRE2: https://github.com/PCRE2Project/pcre2 at tag pcre2-10.48.

Bergamot dependency revisions:
 2781d735d4a10dca876d61be587afdab2726293c 3rd_party/marian-dev (1.9.0-603-g2781d735)
 c19b7814d71febf1053bd93af6ac314b46204092 3rd_party/marian-dev/examples (c19b781)
 16914ae94c80f338c678f0461c4e45965149f6aa 3rd_party/marian-dev/regression-tests (16914ae)
 0e33146d3e7f070c7de9494efef49147a9d20558 3rd_party/marian-dev/src/3rd_party/fbgemm (0e33146)
 4da474ac9aa2689e88d5e40a2f37628f302d7e3c 3rd_party/marian-dev/src/3rd_party/fbgemm/third_party/asmjit (4da474a)
 d5e37adf1406cf899d7d9ec1d317c47506ccb970 3rd_party/marian-dev/src/3rd_party/fbgemm/third_party/cpuinfo (d5e37ad)
 0fc5466dbb9e623029b1ada539717d10bd45e99e 3rd_party/marian-dev/src/3rd_party/fbgemm/third_party/googletest (release-1.8.0-1409-g0fc5466d)
 f7401513da71758dacce52fed1c7855549abee59 3rd_party/marian-dev/src/3rd_party/intgemm (v1.0)
 7d3486128ebc865b9f2cad63a5cfd3a8f6abcb5a 3rd_party/marian-dev/src/3rd_party/nccl (v2.3.7-1-1-g7d34861)
 924924b08e9596b41aeebada4a172f026be95f5a 3rd_party/marian-dev/src/3rd_party/onnxjs (heads/master)
 fff37f4ca0397af9ed7e04f3bd6b893a1ea2b08e 3rd_party/marian-dev/src/3rd_party/onnxjs/deps/eigen (3.3.0-347-gfff37f4ca)
 2d950b3bfa7ebfbe7a97ecb44b1cc4da5ac1d6f0 3rd_party/marian-dev/src/3rd_party/ruy (2d950b3)
 5916273f79a21551890fd3d56fc5375a78d1598d 3rd_party/marian-dev/src/3rd_party/ruy/third_party/cpuinfo (5916273)
 6c58c11d5497b6ee1df3cb400ce30deb72fc28c0 3rd_party/marian-dev/src/3rd_party/ruy/third_party/googletest (release-1.8.0-2588-g6c58c11d)
 ae41b7740d7006596bb9257e83340b2620db9d00 3rd_party/marian-dev/src/3rd_party/sentencepiece (v0.1.4-252-gae41b77)
 d0793d86aea9036a5bc77b9ca7791dff024168ca 3rd_party/marian-dev/src/3rd_party/simd_utils (d0793d8)
 417a2a9e9dbd720b8d2dfa1dafe57cf1b37ca0d7 3rd_party/marian-dev/src/3rd_party/simple-websocket-server (v2.0.0-rc3-107-g417a2a9)
 9ec1128c7aac3d069a4ec2bd1dfc7f57c6526d1c 3rd_party/pybind11 (v2.9.0-37-g9ec1128c)
 a311f9865ade34db1e8e080e6cc146f55dafb067 3rd_party/ssplit-cpp (heads/master)
 a04432d7921bfa1dd62bc2e5cdca46b226f256de bergamot-translator-tests (heads/main)

